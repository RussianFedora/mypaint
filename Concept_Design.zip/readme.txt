
================================================
MyPaint 0.9.0 (or later) BrushPackage release                                                          
*****  "Concept Design (C_D)"  *****                           
                                               
www.ramonmiranda.com 
mirandagraphic@gmail.com                                           
================================================
A briefs words...
-----------------
"Concept Design" idea comes from conceptual design, where Markers and inks are very useful. I thought that it would be fun to have something similar inside mypaint so i made them.in this set we have 16 brushes with specific functions to improve the workflows and productivity.
so please, feel free to change order, mix with other sets or whatever you want.

Install notes
-------------
When install popup menu appears, select "OK" to install and then select the "Rename all" option if you want to have an independent set, or "Replace all" if you want to remove the older brushes.

License
-------
Copyright 2011 Ramon Miranda

Except where otherwise noted, these brushes are licensed under a Creative Commons Attribution 3.0 Unported License. See http://creativecommons.org/licenses/by/3.0/ for details.

As an exception to this and to the extent possible under law, Ramon Miranda has waived all copyright and related or neighboring rights to the raw brush settings (those files ending with ".myb"). See http://creativecommons.org/publicdomain/zero/1.0/ for details.                                                 ================================================

